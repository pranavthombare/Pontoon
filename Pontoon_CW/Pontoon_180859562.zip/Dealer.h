#ifndef DEALER_H
#define DEALER_H

#include "Player.h"
#include <string>

class Dealer : public Player
{
public:
	Dealer();
	void showOne();
	void show();
};

#endif 