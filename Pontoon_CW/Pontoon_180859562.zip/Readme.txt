Run using the following code

g++ -o pontoon *.cpp --std=c++14
./pontoon
